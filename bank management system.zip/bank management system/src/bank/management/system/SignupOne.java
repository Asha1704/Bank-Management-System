
package bank.management.system;

import java.awt.Font;
import javax.swing.*;
import java.util.*;
//to make a calender we need to import JDateChooser and for that we need to add jcalender jar file
import com.toedter.calendar.JDateChooser;
import java.awt.Color;
import java.awt.event.*;




public class SignupOne extends JFrame implements ActionListener {
    long random;
    JTextField nameTextField, fnameTextField, dobTextField, emailTextField, addTextField,cityTextField, stateTextField, pincodeTextField; 
    JRadioButton male, female, other, other1, married, single;
    JDateChooser dateChooser;
    JButton next;
    
    
    SignupOne(){
        setLayout(null); //setbounds will work when setlayout is null
        Random rand = new Random();
        random = Math.abs((rand.nextLong() % 1000L)+1000L); //it will create 4 no. random 
        //System.out.println(random);
        
        JLabel formno = new JLabel("Application Form No."+ random);//label for creating a label and it generates a random app form no
        formno.setFont(new Font("Raleway",Font.BOLD,38));
        formno.setBounds(140,20,600,40);
        add(formno);
        
        JLabel personDetails = new JLabel("Page 1 - Personal Details");//label for creating a label and it generates a random app form no
        personDetails.setFont(new Font("Raleway",Font.BOLD,22));
        personDetails.setBounds(290,80,400,30);
        add(personDetails);
        
        JLabel name = new JLabel("Name:");//label for creating a label and it generates a random app form no
        name.setFont(new Font("Raleway",Font.BOLD,20));
        name.setBounds(100,140,100,30);
        add(name);
        
        nameTextField = new JTextField();
        nameTextField.setFont(new Font("Raleway",Font.BOLD,14));
        nameTextField.setBounds(300,140,400,30);
        add(nameTextField);
        
        JLabel fname = new JLabel("Father's Name:");//label for creating a label and it generates a random app form no
        fname.setFont(new Font("Raleway",Font.BOLD,20));
        fname.setBounds(100,190,200,30);
        add(fname);
        
        fnameTextField = new JTextField();
        fnameTextField.setFont(new Font("Raleway",Font.BOLD,14));
        fnameTextField.setBounds(300,190,400,30);
        add(fnameTextField);
        
        JLabel dob = new JLabel("Date of Birth:");//label for creating a label and it generates a random app form no
        dob.setFont(new Font("Raleway",Font.BOLD,20));
        dob.setBounds(100,240,200,30);
        add(dob);
        
        dateChooser = new JDateChooser();
        dateChooser.setBounds(300,240,400,30);
        dateChooser.setForeground(new Color(105,105,105));
        add(dateChooser);
        
        
        
        
        JLabel gen = new JLabel("Gender:");//label for creating a label and it generates a random app form no
        gen.setFont(new Font("Raleway",Font.BOLD,20));
        gen.setBounds(100,290,200,30);
        add(gen);
        
        male = new JRadioButton("Male");
        male.setBounds(300,290,60,30);
        male.setBackground(Color.WHITE);
        add(male);
        
        female = new JRadioButton("Female");
        female.setBounds(450,290,120,30);
        female.setBackground(Color.WHITE);
        add(female);
        
        other = new JRadioButton("Other");
        other.setBounds(600,290,120,30);
        other.setBackground(Color.WHITE);
        add(other);
        
        //buttongroup helps to choose only one at a time
        ButtonGroup gendergroup = new ButtonGroup();
        gendergroup.add(male);
        gendergroup.add(female);
        gendergroup.add(other);
        
        JLabel email = new JLabel("Email:");//label for creating a label and it generates a random app form no
        email.setFont(new Font("Raleway",Font.BOLD,20));
        email.setBounds(100,340,200,30);
        add(email);
        
        emailTextField = new JTextField();
        emailTextField.setFont(new Font("Raleway",Font.BOLD,14));
        emailTextField.setBounds(300,340,400,30);
        add(emailTextField);
        
        JLabel ms = new JLabel("Marital Status:");//label for creating a label and it generates a random app form no
        ms.setFont(new Font("Raleway",Font.BOLD,20));
        ms.setBounds(100,390,200,30);
        add(ms);
        
        single = new JRadioButton("Single");
        single.setBounds(300,390,100,30);
       single.setBackground(Color.WHITE);
        add(single);
        
        married = new JRadioButton("Married");
        married.setBounds(450,390,100,30);
        married.setBackground(Color.WHITE);
        add( married);
        
        other1 = new JRadioButton("Other");
        other1.setBounds(600,390,100,30);
        other1.setBackground(Color.WHITE);
        add(other1);
        
        //buttongroup helps to choose only one at a time
        ButtonGroup msgroup = new ButtonGroup();
        msgroup.add(single);
        msgroup.add(married);
        msgroup.add(other1);
        
        JLabel add = new JLabel("Address:");//label for creating a label and it generates a random app form no
        add.setFont(new Font("Raleway",Font.BOLD,20));
        add.setBounds(100,440,200,30);
        add(add);
        
        addTextField = new JTextField();
        addTextField.setFont(new Font("Raleway",Font.BOLD,14));
        addTextField.setBounds(300,440,400,30);
        add(addTextField);
        
        
        
        JLabel city = new JLabel("City:");//label for creating a label and it generates a random app form no
        city.setFont(new Font("Raleway",Font.BOLD,20));
        city.setBounds(100,490,200,30);
        add(city);
        
        cityTextField = new JTextField();
        cityTextField.setFont(new Font("Raleway",Font.BOLD,14));
        cityTextField.setBounds(300,490,400,30);
        add(cityTextField);
        
        JLabel state = new JLabel("State:");//label for creating a label and it generates a random app form no
        state.setFont(new Font("Raleway",Font.BOLD,20));
        state.setBounds(100,540,200,30);
        add(state);
        
        stateTextField = new JTextField();
        stateTextField.setFont(new Font("Raleway",Font.BOLD,14));
        stateTextField.setBounds(300,540,400,30);
        add(stateTextField);
        
        
        
        JLabel pincode = new JLabel("Pin Code:");//label for creating a label and it generates a random app form no
        pincode.setFont(new Font("Raleway",Font.BOLD,20));
        pincode.setBounds(100,590,200,30);
        add(pincode);
        
        pincodeTextField = new JTextField();
        pincodeTextField.setFont(new Font("Raleway",Font.BOLD,14));
        pincodeTextField.setBounds(300,590,400,30);
        add(pincodeTextField);
        
        
        //NEXT BUTTON
        next = new JButton("Next");
        next.setBackground(Color.BLACK);
        next.setForeground(Color.WHITE);
        next.setFont(new Font("Raleway",Font.BOLD,14));
        next.setBounds(620,660,80,30);
        next.addActionListener(this);
        add(next);
                
                
                
                
                
        getContentPane().setBackground(Color.WHITE);
        setSize(850,800);
        setVisible(true);
        setLocation(350,10);
        
    }
    public void actionPerformed(ActionEvent ae){
        String formno = "" + random; //its a long and to be stored in db it must be a string value so need to convert it
        String name = nameTextField.getText();
        String fname = fnameTextField.getText();
        String dob = ((JTextField) dateChooser.getDateEditor().getUiComponent()).getText();//converted into textfield because gettext works only on textfield
        String gender = null;
        if(male.isSelected()){
            gender = "Male";
        }else if(female.isSelected()){
            gender = "Female";
        }else if(other.isSelected()){
            gender = "Other";
        }
       
        String email = emailTextField.getText();
        String ms = null;
        if(single.isSelected()){
            ms = "Single";
            
        }else if (married.isSelected()){
            ms = "Married";
        }else if (other1.isSelected()){
            ms = "Other";
        }
        
        String add = addTextField.getText();
        String city = cityTextField.getText();
        String state = stateTextField.getText();
        String pincode = pincodeTextField.getText();
        
        
        try {
            if(name.equals("")){
                JOptionPane.showMessageDialog(null, "Name is Required");
            }else{
                Conn c = new Conn();
                String query = "insert into signup values('"+formno+"','"+name+"','"+fname+"','"+dob+"', '"+email+"','"+gender+"','"+ms+"','"+add+"','"+city+"','"+state+"','"+pincode+"')";
                c.s.executeUpdate(query);
                
                //to open the signuptwo page
                setVisible(false);
                new SignupTwo(formno).setVisible(true);
            }
            
        
        }catch (Exception e){
            System.out.println(e);
        }
    }
    
    
    
    
    
    public static void main(String args[]){
        new SignupOne();
    }
    
    
}

