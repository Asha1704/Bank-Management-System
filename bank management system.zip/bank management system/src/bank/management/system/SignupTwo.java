/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bank.management.system;
import java.awt.Font;
import javax.swing.*;
import java.util.*;
import java.awt.Color;
import java.awt.event.*;




public class SignupTwo extends JFrame implements ActionListener {
    
    JTextField nameTextField, fnameTextField, dobTextField, emailTextField, addTextField,cityTextField, stateTextField, pincodeTextField; 
    JRadioButton male, female, other, other1, married, single;
   // JDateChooser dateChooser;
    JButton next;
    JComboBox rel, cat, incat, edu1, edu2;
    JRadioButton syes, sno, eyes, eno;
    JTextField pan1, aadhar;
    String formno;
   
    
    SignupTwo(String formno){
        //doing this to make the formno as primary key so that signupone and signuptwo can corelate
        this.formno =formno;
        setLayout(null); //setbounds will work when setlayout is null
        setTitle("NEW ACCOUNT FORM - PAGE 2");
        
        
        
        
        JLabel additionalDetails = new JLabel("Page 2 - Additional Details");//label for creating a label and it generates a random app form no
        additionalDetails.setFont(new Font("Raleway",Font.BOLD,22));
        additionalDetails.setBounds(290,80,400,30);
        add(additionalDetails);
        
        JLabel religion = new JLabel("Religion:");//label for creating a label and it generates a random app form no
        religion.setFont(new Font("Raleway",Font.BOLD,20));
        religion.setBounds(100,140,100,30);
        add(religion);
        
        String varReligion[] = {"Hindu","Sikh","Christian","Other"};
        rel = new JComboBox(varReligion);
        rel.setBounds(300,140,400,30);
        rel.setBackground(Color.WHITE);
        add(rel);
                    
          
        JLabel category = new JLabel("Category:");//label for creating a label and it generates a random app form no
        category.setFont(new Font("Raleway",Font.BOLD,20));
        category.setBounds(100,190,200,30);
        add(category);
        
        String valcategory[] = {"General","OBC","SC","ST","Others"};
        cat = new JComboBox(valcategory);
        cat.setBounds(300,190, 400, 30);
        cat.setBackground(Color.WHITE);
        add(cat);
       
        
        JLabel income = new JLabel("Income:");//label for creating a label and it generates a random app form no
        income.setFont(new Font("Raleway",Font.BOLD,20));
        income.setBounds(100,240,200,30);
        add(income);
        
        String incategory[] = {"Null","<1,50,000","<2,50,000","<3,50,000","upto 10L"};
        incat = new JComboBox(incategory);
        incat.setBounds(300, 240, 400, 30);
        incat.setBackground(Color.WHITE);
        add(incat);

        JLabel education = new JLabel("Educational:");//label for creating a label and it generates a random app form no
        education.setFont(new Font("Raleway",Font.BOLD,20));
        education.setBounds(100,290,200,30);
        add(education);
        

        
        JLabel qua = new JLabel("Qualification:");//label for creating a label and it generates a random app form no
        qua.setFont(new Font("Raleway",Font.BOLD,20));
        qua.setBounds(100,315,200,30);
        add(qua);
        
        String edu[] = {"Graduated","Post-Graduated","Doctrate","Other"};
        edu1 = new JComboBox(edu);
        edu1.setBounds(300, 315, 400, 30);
        edu1.setBackground(Color.WHITE);
        add(edu1);
        
        
        
        JLabel occ= new JLabel("Occupation:");//label for creating a label and it generates a random app form no
        occ.setFont(new Font("Raleway",Font.BOLD,20));
        occ.setBounds(100,390,200,30);
        add(occ);
        
        String edu11[] = {"Salaried","Self-Employed","Business","Student","Other"};
        edu2 = new JComboBox(edu11);
        edu2.setBounds(300, 390, 400, 30);
        edu2.setBackground(Color.WHITE);
        add(edu2);
        
       
        
        
        JLabel pan = new JLabel("Pan No.:");//label for creating a label and it generates a random app form no
        pan.setFont(new Font("Raleway",Font.BOLD,20));
        pan.setBounds(100,440,200,30);
        add(pan);
        
        pan1 = new JTextField();
        pan1.setFont(new Font("Raleway",Font.BOLD,14));
        pan1.setBounds(300,440,400,30);
        add(pan1);
        
        
        
        JLabel an = new JLabel("Aadhar No:");//label for creating a label and it generates a random app form no
        an.setFont(new Font("Raleway",Font.BOLD,20));
        an.setBounds(100,490,200,30);
        add(an);
        
        aadhar = new JTextField();
        aadhar.setFont(new Font("Raleway",Font.BOLD,14));
        aadhar.setBounds(300,490,400,30);
        add(aadhar);
        
        JLabel sc = new JLabel("Senior Citizen:");//label for creating a label and it generates a random app form no
        sc.setFont(new Font("Raleway",Font.BOLD,20));
        sc.setBounds(100,540,200,30);
        add(sc);
        
        syes = new JRadioButton("Yes");
        syes.setBounds(300,540,100,30);
        syes.setBackground(Color.WHITE);
        add(syes);
        
        sno = new JRadioButton("No");
        sno.setBounds(450,540,100,30);
        sno.setBackground(Color.WHITE);
        add( sno);
        
        ButtonGroup msgroup = new ButtonGroup();
        msgroup.add(syes);
        msgroup.add(sno);
        
        
        
        JLabel exacc = new JLabel("Existing Account:");//label for creating a label and it generates a random app form no
        exacc.setFont(new Font("Raleway",Font.BOLD,20));
        exacc.setBounds(100,590,200,30);
        add(exacc);
        
        eyes = new JRadioButton("Yes");
        eyes.setBounds(300,590,100,30);
        eyes.setBackground(Color.WHITE);
        add(eyes);
        
        eno = new JRadioButton("No");
        eno.setBounds(450,590,100,30);
        eno.setBackground(Color.WHITE);
        add( eno);
        
        ButtonGroup msgroup1 = new ButtonGroup();
        msgroup1.add(eyes);
        msgroup1.add(eno);
        
        
        //NEXT BUTTON
        next = new JButton("Next");
        next.setBackground(Color.BLACK);
        next.setForeground(Color.WHITE);
        next.setFont(new Font("Raleway",Font.BOLD,14));
        next.setBounds(620,660,80,30);
        next.addActionListener(this);
        add(next);
                
                
                
                
                
        getContentPane().setBackground(Color.WHITE);
        setSize(850,800);
        setVisible(true);
        setLocation(350,10);
        
    }
    public void actionPerformed(ActionEvent ae){
      
        String sreligion = (String) rel.getSelectedItem();
        String scategory = (String) cat.getSelectedItem();
        String sincome = (String) incat.getSelectedItem();
        String seducation = (String) edu1.getSelectedItem();
        String soccupation = (String) edu2.getSelectedItem();
        String seniorcitizen=null;
        if(syes.isSelected()){
            seniorcitizen = "Yes";
        }
        else{
            seniorcitizen="No";
        }
        
       
        
        String existingaccount = null;
        if(eyes.isSelected()){
            existingaccount = "Yes";
            
        }else {
            existingaccount = "No";
        }
        
        String span = pan1.getText();
        String saadhar = aadhar.getText();
        
        
        
        try {
            if(aadhar.equals("")){
                JOptionPane.showMessageDialog(null, "Aadhar No. is Required");
            } 
            else{
                Conn c = new Conn();
                String query = "insert into signuptwo values('"+formno+"','"+sreligion+"','"+scategory+"','"+sincome+"', '"+seducation+"','"+soccupation+"','"+span+"','"+saadhar+"','"+seniorcitizen+"','"+existingaccount+"')";
                c.s.executeUpdate(query);
                setVisible(false);
                new Signupthree(formno).setVisible(true);
                
                //new Signupthree().setVisible(true);
                
                
            }
            
        
        }catch (Exception e){
            System.out.println(e);
        }
    }


/**
 *
 * @author 917690970008
 */
    public static void main(String args[]) {
        
        new SignupTwo("");
 
       

}
    
}
