/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bank.management.system; //package

import javax.swing.*; // package that gives JFrame to make frame
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

// After extending the JFrame for making frame we will implement the ActionListener interface which is used to perform actions on the frame
public class Login extends JFrame implements ActionListener{
    JButton login, signup, clear;
    JTextField cardTextField;
    JPasswordField pinTextField;
    
    

    
    Login(){
        setLayout(null);
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/logo.jpg"));
        Image i2 = i1.getImage().getScaledInstance(100,100, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel label = new JLabel(i3);
        label.setBounds(70,10,100,100);
        add(label); //performed actions with the icons
        
        JLabel text = new JLabel("Welcome to ATM");
        text.setFont(new Font("Osward", Font.BOLD,38));
        text.setBounds(200, 40, 400, 40);
        add(text);
        
       
        
        JLabel  cardno = new JLabel("Card No: ");
        cardno.setFont(new Font("Raleway", Font.BOLD,28));
        cardno.setBounds(120, 150, 400, 30);
        add(cardno);
        
        //now will make text field by using jtextfield
        cardTextField = new JTextField();
        cardTextField.setBounds(300, 150, 230, 30);
        cardTextField.setFont(new Font("Arial",Font.BOLD,14));
        add(cardTextField);
        
        JLabel pin = new JLabel("PIN: ");
        pin.setFont(new Font("Raleway", Font.BOLD,28));
        pin.setBounds(120, 220, 400, 30);
        add(pin);
        
        pinTextField = new JPasswordField();
        pinTextField.setBounds(300, 220, 230, 30);
        pinTextField.setFont(new Font("Arial",Font.BOLD,14));
        add(pinTextField);
        
        
        // now will make the buttons
        login = new JButton("SIGN IN");
        login.setBounds(300,290,100,30);
        login.setBackground(Color.BLACK);
        login.setForeground(Color.WHITE);
        login.addActionListener(this); 
        add(login);
        
        clear = new JButton("CLEAR");
        clear.setBounds(430,290,100,30);
        clear.setBackground(Color.BLACK);
        clear.setForeground(Color.WHITE);
        clear.addActionListener(this); //this step is necessARY for working of actionPerformed
        add(clear);
        
        signup = new JButton("SIGN UP");
        signup.setBounds(300,350,230,30);
        signup.setBackground(Color.BLACK);
        signup.setForeground(Color.WHITE);
        signup.addActionListener(this); 
        
        add(signup);
        
        
                
                
        
        
        getContentPane().setBackground(Color.WHITE);
        setTitle("Automated Teller Machine");
        setSize(800,470); //sets the length and bredth of the frame
        setVisible(true); //bydefault visibility is false so need to make it true
        setLocation(350,200); //by default frame opens on the top left and we can adjust it by this fun
        
    }
    
    public void actionPerformed(ActionEvent e){
        if (e.getSource()==clear){
            cardTextField.setText("");
            pinTextField.setText("");
            
            
        } else if(e.getSource()==login){
            Conn conn = new Conn();
            String cardnumber = cardTextField.getText();
            String pinnumber = pinTextField.getText();
            String query = "select * from login where cardnumber = '"+cardnumber+"' and pin = '"+pinnumber+"'";
            try{
                ResultSet rs =  conn.s.executeQuery(query);
                if(rs.next()){
                    setVisible(false);
                    new Transactions(pinnumber).setVisible(true);
                }else{
                    JOptionPane.showMessageDialog(null,"Incorrect Card Number or Pin");
                }
            }catch(Exception e1){
                System.out.println(e1);
            }
            
            
        }else if(e.getSource()==signup){
            setVisible(false);
            new SignupOne().setVisible(true);
            
        }
        
    }

    
    
    public static void main(String args[]){
        new Login().setVisible(true); //anpnymus function that calls the constructor
    }
}
