
package bank.management.system;
import java.sql.*;

// steps of jdbc connection
//--1-- Register the driver
//--2-- create connection
//--3-- create statement
//--4--execute query
//--5-- close connection


public class Conn {
     //make an obj of Connection class
    Connection c;
    Statement s;
    
    public Conn(){ 
        // we will use try catch here because jdbc is an external entity and it will not give error at compile time but at run time
        try{
            //register the driver
            // now no need to register this because we added the connector in library;;;;;   Class.forName(com.mysql.cj.jdbc.Driver);
            //create conn
            c = DriverManager.getConnection("jdbc:mysql:///bankmanagementsystem", "root" , "Khotu@3974");
            //create statement
            s = c.createStatement();
            
            
        }
        catch(Exception e){
            System.out.println("e");
          
        }
    }
    
    
    
    
}
